package es.iespuerto.area;
/*
String tipo. Qué será el tipo de area que va a almacenar (ej: triángulo, cuadrado, etc).
Integer valor1. Valor del primer parámetro para el cálculo del área.
Integer valor2. Valor del segundo parámetro para el cálculo del área.
Constructores:
Constructor por defecto, sin parámetros.
Constructor con un parámetro.
Constructor con dos parámetros.
Métodos:
CalculoArea. Método que recibe como parámetros valor1, y valor2.
 */
public class Angel {
    /**
     * Propiedades
     */
    private String tipo;
    private String valor1;
    private String valor2;

    /**
     * Constructor por defecto, sin parámetros.
     */
    public Angel(){

    }

    public static void main(String[] args) {

    }
}
